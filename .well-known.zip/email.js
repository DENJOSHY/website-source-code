// Handle File Upload and Convert to Base64
// let uploadedFileBase64 = "";

//File upload
// document.addEventListener("DOMContentLoaded", function () {
//   const fileUploadArea = document.getElementById("file-upload-area");
//   const fileInput = document.getElementById("file-input");
//   const fileInfo = document.getElementById("file-info");

//   // Drag and drop events
//   fileUploadArea.addEventListener("dragover", (event) => {
//     event.preventDefault();
//     event.stopPropagation();
//     fileUploadArea.classList.add("drag-over");
//   });

//   fileUploadArea.addEventListener("dragleave", (event) => {
//     event.preventDefault();
//     event.stopPropagation();
//     fileUploadArea.classList.remove("drag-over");
//   });

//   fileUploadArea.addEventListener("drop", (event) => {
//     event.preventDefault();
//     event.stopPropagation();
//     fileUploadArea.classList.remove("drag-over");

//     const files = event.dataTransfer.files;
//     if (files.length > 0) {
//       handleFileUpload(files[0]);
//     }
//   });

//   // Input change event
//   fileInput.addEventListener("change", (event) => {
//     const files = event.target.files;
//     if (files.length > 0) {
//       handleFileUpload(files[0]);
//     }
//   });

//   // Handle file upload
//   function handleFileUpload(file) {
//     const validExtensions = ["image/jpeg", "image/png", "application/pdf"];
//     const maxSizeInBytes = 5 * 1024 * 1024; // 5 MB
//     if (file.size > maxSizeInBytes) {
//       fileInfo.textContent = "File is too large. Maximum size is 5MB.";
//       fileInfo.style.color = "#f44336"; // Red for error
//       return;
//     }
//     if (validExtensions.includes(file.type)) {
//       const reader = new FileReader();
//       reader.onload = function () {
//         uploadedFileBase64 = reader.result.split(",")[1]; // Extract base64 part
//       };
//       reader.readAsDataURL(file);

//       fileInfo.textContent = `File selected: ${file.name}`;
//       fileInfo.style.color = "#4CAF50"; // Green for success
//     } else {
//       fileInfo.textContent = "Invalid file type. Please upload a PDF or image.";
//       fileInfo.style.color = "#f44336"; // Red for error
//     }
//   }
// });

// Contact Form
document.addEventListener("DOMContentLoaded", function () {
  // Initialize EmailJS
  emailjs.init("gs6KATm3RGOZNlLGO");

  const form = document.getElementById("contact-form");

  // Toast Notification Function
  function showToast(message, type = "success") {
    const toast = document.getElementById("toast");
    toast.querySelector(".toast-message").textContent = message;
    toast.querySelector(".toast-icon").textContent =
      type === "success" ? "✓" : "✕";
    toast.querySelector(".toast-icon").style.backgroundColor =
      type === "success" ? "#4CAF50" : "#f44336";
    toast.classList.add("show");

    setTimeout(() => {
      toast.classList.remove("show");
    }, 3000);
  }

  // Validation for Phone
  function validatePhone(phone) {
    const phoneRegex =
      /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
    return phoneRegex.test(phone);
  }

  // Validation for Email
  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Validation for Website
  function validateWebsite(website) {
    const websiteRegex = /^(https:\/\/)?www\.[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$/;
    return websiteRegex.test(website);
  }

  // Real-time validation
  const phoneInput = document.getElementById("phone");
  phoneInput.addEventListener("input", function () {
    if (!validatePhone(this.value)) {
      this.setCustomValidity("Please enter a valid phone number");
    } else {
      this.setCustomValidity("");
    }
  });

  const emailInput = document.getElementById("email");
  emailInput.addEventListener("input", function () {
    if (!validateEmail(this.value)) {
      this.setCustomValidity("Please enter a valid email address");
    } else {
      this.setCustomValidity("");
    }
  });

  const websiteInput = document.getElementById("website");
  websiteInput.addEventListener("input", function () {
    if (!validateWebsite(this.value)) {
      this.setCustomValidity(
        "Please enter a valid website URL (e.g., www.example.com or https://www.example.com)"
      );
    } else {
      this.setCustomValidity("");
    }
  });

  // Form submission handler
  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.classList.add("loading");
    submitButton.textContent = "Sending...";

    // Prepare form data for EmailJS
    const templateParams = {
      name: form.querySelector('[name="name"]').value,
      company: form.querySelector('[name="company"]').value,
      email: form.querySelector('[name="email"]').value,
      phone: form.querySelector('[name="phone"]').value,
      website: form.querySelector('[name="website"]').value,
      collaboration: form.querySelector('[name="collaboration"]').value,
      regions: form.querySelector('[name="regions"]').value,
      volume: form.querySelector('[name="volume"]').value,
      contact_method: Array.from(
        form.querySelectorAll('[name="contact_method"]:checked')
      )
        .map((checkbox) => checkbox.value)
        .join(", "),
      message: form.querySelector('[name="message"]').value,
      source: form.querySelector('[name="source"]').value,
      // attachment: uploadedFileBase64,
    };

    emailjs
      .send("service_05g8qkg", "template_tuudo0r", templateParams)
      .then((response) => {
        console.log("SUCCESS!", response.status, response.text);
        submitButton.classList.remove("loading");
        submitButton.textContent = "Submit Application";
        showToast(
          "Thank you for your message. We'll get back to you soon!",
          "success"
        );
        form.reset();
      })
      .catch((error) => {
        console.log("FAILED...", error);
        submitButton.classList.remove("loading");
        submitButton.textContent = "Submit Application";
        showToast("Failed to send message. Please try again.", "error");
      });
  });
});

// Add loading spinner styles if not already in your CSS
const styleSheet = document.createElement("style");
styleSheet.textContent = `
    button.loading {
        position: relative;
        color: transparent;
    }
    button.loading::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 20px;
        height: 20px;
        margin: -10px 0 0 -10px;
        border: 2px solid #fff;
        border-top-color: transparent;
        border-radius: 50%;
        animation: button-loading-spinner 1s linear infinite;
    }
    @keyframes button-loading-spinner {
        from {
            transform: rotate(0deg);
        }
        to {
            transform: rotate(360deg);
        }
    }
`;
document.head.appendChild(styleSheet);
